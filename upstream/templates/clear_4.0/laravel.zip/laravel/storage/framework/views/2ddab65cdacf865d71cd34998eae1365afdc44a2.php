  <?php $__env->startSection('title'); ?> Advanced Maps <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/leaflet/css/leaflet.css')); ?>" />
<style>
    .leaflet-top, .leaflet-bottom{
        z-index: 99;
    }
</style>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Advanced Maps</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Maps</li>
        <li class="active">
            Advanced Maps
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="ti-location-arrow"></i> Basic
                    </h4>
                    <span class="float-right">
                                <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard"></i>
                                </span>
                </div>
                <div class="card-body" style="padding:10px !important;">
                    <div id="advanced_map" class="gmap"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendors/leaflet/js/leaflet-src.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/custom_js/advanced_maps.js')); ?>"></script> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/menubarfold', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>