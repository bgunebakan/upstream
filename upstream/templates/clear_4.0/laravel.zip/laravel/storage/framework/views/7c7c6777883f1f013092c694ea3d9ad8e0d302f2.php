  <?php $__env->startSection('title'); ?> Amcharts <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendors/amcharts/css/export.css')); ?>" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom_css/amcharts.css')); ?>"> <?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Amcharts</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Charts</li>
        <li class="active">
            Amcharts
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <!-- Basic charts strats here-->
            <div class="card ">
                <div class="card-header">
                    <h4 class="card-title card_header1024">
                        <i class="ti-bar-chart"></i> Column and Line mix Chart
                    </h4>
                    <span class="float-right">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard "></i>
                                </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="amchart1" id="chart1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <!-- Basic charts strats here-->
            <div class="card column">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="ti-bar-chart-alt"></i> Column chart with images on top
                    </h4>
                    <span class="float-right">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard "></i>
                                </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="amchart1" id="chart3"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row -->
    <div class="row">
        <div class="col-md-12">
            <!-- Basic charts strats here-->
            <div class="card ">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="ti-bar-chart"></i> 3D Stacked Column Chart
                    </h4>
                    <span class="float-right">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard "></i>
                                </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="amchart1" id="chart2"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row -->
    <div class="row">
        <div class="col-md-6">
            <!-- Basic charts strats here-->
            <div class="card ">
                <div class="card-header">
                    <h4 class="card-title card_header1024">
                        <i class="ti-bar-chart"></i> Duration on Value Axis Chart
                    </h4>
                    <span class="float-right">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard "></i>
                                </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="amchart1" id="chart4"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <!-- Basic charts strats here-->
            <div class="card ">
                <div class="card-header">
                    <h4 class="card-title card_header1024">
                        <i class="ti-bar-chart-alt"></i> Reversed Value Axis Chart
                    </h4>
                    <span class="float-right">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard "></i>
                                </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="amchart1" id="chart5"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row -->
    <!--rightside bar -->
<?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendors/amcharts/js/amcharts.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendors/amcharts/js/serial.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendors/amcharts/js/export.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendors/amcharts/js/light.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/custom_js/amcharts.js')); ?>"></script> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/menubarfold', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>