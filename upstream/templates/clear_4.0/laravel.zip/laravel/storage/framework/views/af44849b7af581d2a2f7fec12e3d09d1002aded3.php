  <?php $__env->startSection('title'); ?> Dropify <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendors/dropify/css/dropify.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom_css/dropify.css')); ?>"> <?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Dropify</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Gallery</li>
        <li class="active">
            Dropify
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fa fa-fw ti-dropbox"></i> Dropify
                    </h3>
                    <span class="float-right">
                        <i class="fa fa-fw ti-angle-up clickable"></i>
                        <i class="fa fa-fw ti-close removecard "></i>
                    </span>
                </div>
                <div class="card-body p-30">
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Dropify Basic</h5>
                            <input type="file" class="dropify"/>
                        </div>
                        <div class="col-md-6">
                            <h5>AllowedFileExtensions (PDF, PNG and PSD )</h5>
                            <input type="file" class="dropify" data-allowed-file-extensions="pdf png psd"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Max File Size</h5>
                            <input type="file" data-max-file-size="3M"/>
                        </div>
                        <div class="col-md-6">
                            <h5>Disabled</h5>
                            <input type="file" class="dropify" disabled="disabled"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Default File</h5>
                            <input type="file" class="dropify" data-default-file="img/pages/slider2.jpg"/>
                        </div>
                        <div class="col-md-6">
                            <h5>Without Remove Button</h5>
                            <input type="file" class="dropify" data-show-remove="false"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendors/dropify/js/dropify.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom_js/dropify_custom.js')); ?>" type="text/javascript"></script> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/menubarfold', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>