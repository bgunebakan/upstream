  <?php $__env->startSection('title'); ?> Sweet Alert <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/sweetalert2/css/sweetalert2.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom_css/sweet_alert2.css')); ?>"><?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Sweet Alert</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> UI Components</li>
        <li class="active">
            Sweet Alert
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="ti-bell" aria-hidden="true"></i>
                        Sweet Alerts
                    </h3>
                    <span class="float-right">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard "></i>
                                </span>
                </div>
                <div class="card-body">
                    <!--=============card content starting=============-->
                    <div class="row m-a-10">
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body success_alert text-center">
                                    <h5> Success Alert <i class="fa fa-check-circle-o"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body ok_message text-center">
                                    <h5> Ok Message <i class="fa fa-thumbs-o-up"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body basicalert text-center ">
                                    <h5> Alert <i class="fa fa-bell-o"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body ip_alert text-center">
                                    <h5> Ip Alert <i class="fa fa-info-circle"></i></h5>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!--first row end-->
                    <div class="row m-a-10">
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body custom_icon text-center">
                                    <h5> Custom Image <i class="fa fa-picture-o"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body custom_html text-center">
                                    <h5> Custom Html <i class="fa fa-code"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body auto_close text-center">
                                    <h5> Alert Auto Close <i class="fa fa-magic"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body prom_alert text-center">
                                    <h5> Prompt Alert <i class="fa fa-tree"></i></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--second row end-->
                    <div class="row m-a-10">
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body text-center" id="info-alert">
                                    <h5> Info Alert <i class="fa fa-info"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body text-center" id="success-alert">
                                    <h5> Successfully <i class="fa fa-check"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body text-center" id="warning-alert">
                                    <h5> Warning Alert <i class="fa fa-exclamation"></i></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="card  card-default hvr-sweep-to-right">
                                <div class="card-body text-center" id="danger-alert">
                                    <h5> Danger Alert <i class="fa fa-times"></i></h5>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--third row end-->
                    <!--=================== card content end ======================-->
                </div>
                <!--end of card body-->
            </div>
        </div>
    </div>
    <!--main content ends-->
    <!--rightside bar -->
<?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendors/sweetalert2/js/sweetalert2.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/custom_js/sweetalert.js')); ?>"></script><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/menubarfold', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>