  <?php $__env->startSection('title'); ?> Form Elements <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link href="<?php echo e(asset('vendors/iCheck/css/all.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('vendors/bootstrap-fileinput/css/fileinput.min.css')); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/formelements.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/boxed.css')); ?>"><?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Form Elements</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Forms</li>
        <li> Features</li>
        <li class="active">
            Form Elements
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?>
    <div class="row form-element">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header txt_padding">
                    <h3 class="card-title">
                        <i class="fa fa-fw ti-move"></i> General Elements
                    </h3>
                    <span class="float-right fnt_size txt_font">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard"></i>
                                </span>
                </div>
                <div class="card-body">
                    <form class="form-horizontal" role="form">
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label for="input-text" class="control-label float-right txt_media1">Input text</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="input-text"
                                       placeholder="Input text">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label for="inputPassword" class="control-label float-right txt_media1">Password</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="password" class="form-control" id="inputPassword"
                                       placeholder="Password">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label for="input-text-disabled" class=" control-label float-right txt_media1">Disabled</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="input-text-disabled"
                                       placeholder="Input text" disabled>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label for="color" class="control-label float-right txt_media1">Color</label>
                            </div>
                            <div class="col-sm-10 form_control">
                                <input type="color" class="form-control form_control" id="color">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label for="url" class="control-label float-right txt_media1">Url</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="url" class="form-control" id="url"
                                       placeholder="URL" value="http://getbootstrap.com">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label for="range" class="control-label float-right txt_media1">Range</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="range" class="form-control " id="range" value="50">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right m-t-ng-8 txt_media1">Radio Buttons</label>
                            </div>
                            <div class="col-sm-10">
                                <div class="iradio">
                                    <label>
                                        <input type="radio" name="optionsRadios" id="optionsRadios1"
                                               value="option1"> Radio Button 1
                                    </label>
                                </div>
                                <div class="iradio">
                                    <label>
                                        <input type="radio" name="optionsRadios" id="optionsRadios2"
                                               value="option2"> Radio Button 2
                                    </label>
                                </div>
                                <div class="iradio">
                                    <label>
                                        <input type="radio" name="optionsRadios" id="optionsRadios3"
                                               value="option2"> Radio Button 3
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right m-t-ng-8 txt_media1">Checkbox</label>
                            </div>
                            <div class="col-sm-10">
                                <div>
                                    <label>
                                        <input type="checkbox" name="c1" id="c1" value=""> Checkbox 1
                                    </label>
                                </div>
                                <div>
                                    <label>
                                        <input type="checkbox" name="c1" id="c2" value=""> Checkbox 2
                                    </label>
                                </div>
                                <div>
                                    <label>
                                        <input type="checkbox" name="c1" id="c3" value=""> Checkbox 3
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right txt_media1">
                                    Inline Radio
                                </label>
                            </div>
                            <div class="col-sm-10">
                                <label class="radio-inline iradio">
                                    <input type="radio" id="inlineradio1" name="inlineRadios" value="option1">
                                    Inline Radio Button 1
                                </label>
                                <label class="radio-inline iradio">
                                    <input type="radio" id="inlineradio2" name="inlineRadios" value="option2">
                                    Inline Radio Button 2
                                </label>
                                <label class="radio-inline iradio">
                                    <input type="radio" id="inlineradio3" name="inlineRadios" value="option3">
                                    Inline Radio Button 3
                                </label>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right txt_media1">
                                    Inline Checkbox
                                </label>
                            </div>
                            <div class="col-sm-10">
                                <label class="checkbox-inline icheckbox">
                                    <input type="checkbox" id="inlineCheckbox1" value="option1"> Inline checkbox
                                    1
                                </label>
                                <label class="checkbox-inline icheckbox">
                                    <input type="checkbox" id="inlineCheckbox2" value="option2"> Inline checkbox
                                    2
                                </label>
                                <label class="checkbox-inline icheckbox">
                                    <input type="checkbox" id="inlineCheckbox3" value="option3"> Inline checkbox
                                    3
                                </label>
                            </div>
                        </div>
                        <div class="row form-group has-success">
                            <div class="col-sm-2">
                                <label for="input-text-has-success" class="form-control-label float-right text-success txt_media1">
                                    Input Success
                                </label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control brdr_success" id="input-text-has-success">
                            </div>
                        </div>
                        <div class="row form-group has-warning">
                            <div class="col-sm-2">
                                <label for="input-text-has-warning" class="control-label float-right text-warning txt_media1">
                                    Input Warning
                                </label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control brdr_warn" id="input-text-has-warning">
                            </div>
                        </div>
                        <div class="row form-group has-error">
                            <div class="col-sm-2">
                                <label for="input-text-has-error" class="control-label text-danger float-right txt_media1">
                                    Input Error
                                </label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control brdr_danger" id="input-text-has-error">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right txt_media1">Input Size</label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control input-sm ipt_size" placeholder="input-sm">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right"></label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control ipt_size1" placeholder="input-md">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right"></label>
                            </div>
                            <div class="col-sm-10">
                                <input type="text" class="form-control input-lg ipt_size2" placeholder="input-lg">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right txt_media1">
                                    Input Group
                                </label>
                            </div>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <div class="input-group-prepend ">
                                        <span class="input-group-text">@</span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Username" >
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right"></label>
                            </div>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Currency">
                                    <div class="input-group-append ">
                                        <span class="input-group-text">.00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class=" control-label float-right txt_media"></label>
                            </div>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">$</span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Currency">
                                    <div class="input-group-append ">
                                        <span class="input-group-text">.00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right"></label>
                            </div>
                            <div class="col-sm-10">
                                <div class="row">
                                    <div class="col-md-6 m-b-10">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                            <input type="checkbox">
                                                        </span>
                                            </div>
                                            <input type="text" class="form-control">
                                        </div>
                                        <!-- /input-group -->
                                    </div>
                                    <!-- /.col-lg-6 -->
                                    <div class="col-md-6 m-b-10">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                            <input type="radio">
                                                        </span>
                                            </div>
                                            <input type="text" class="form-control">
                                        </div>
                                        <!-- /input-group -->
                                    </div>
                                    <!-- /.col-lg-6 -->
                                </div>
                                <!-- /.row -->
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right"></label>
                            </div>
                            <div class="col-sm-10">
                                <div class="row">
                                    <div class="col-lg-6 m-b-10">
                                        <div class="input-group input_height">
                                            <div class="input-group-prepend">
                                                <button class="btn btn-warning text-white" type="button">Go!</button>
                                            </div>
                                            <input type="text" class="form-control">
                                        </div>
                                        <!-- /input-group -->
                                    </div>
                                    <!-- /.col-lg-6 -->
                                    <div class="col-lg-6 m-b-10">
                                        <div class="input-group input_height">
                                            <input type="text" class="form-control">
                                            <div class="input-group-append">
                                                <button class="btn btn-warning text-white" type="button">Go!</button>
                                            </div>
                                        </div>
                                        <!-- /input-group -->
                                    </div>
                                    <!-- /.col-lg-6 -->
                                </div>
                                <!-- /.row -->
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class=" control-label float-right"></label>
                            </div>
                            <div class="col-sm-10">
                                <div class="row">
                                    <div class="col-lg-6 m-b-10">
                                        <div class="input-group input_height">
                                            <div class="input-group-prepend">
                                                <button type="button" class="btn btn-info dropdown-toggle dropdown-toggle-split text-white"  aria-haspopup="true" data-toggle="dropdown">
                                                    Action
                                                    <span class="caret"></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown_position1">
                                                    <li>
                                                        <a href="#" class="dropdown-item">Action</a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="dropdown-item">
                                                            Another action
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="dropdown-item">
                                                            Something else here
                                                        </a>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li>
                                                        <a href="#" class="dropdown-item">
                                                            Separated link
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <input type="text" class="form-control">
                                        </div>
                                        <!-- /input-group -->
                                    </div>
                                    <!-- /.col-lg-6 -->
                                    <div class="col-lg-6 m-b-10">
                                        <div class="input-group input_height">
                                            <input type="text" class="form-control">
                                            <div class="input-group-append">
                                                <button type="button" class="btn btn-info dropdown-toggle dropdown-toggle-split text-white"  aria-haspopup="true" data-toggle="dropdown">
                                                    Action
                                                    <span class="caret"></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown_position2">
                                                    <li>
                                                        <a href="#" class="dropdown-item">Action</a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="dropdown-item">
                                                            Another action
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" class="dropdown-item">
                                                            Something else here
                                                        </a>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li>
                                                        <a href="#" class="dropdown-item">
                                                            Separated link
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- /input-group -->
                                    </div>
                                    <!-- /.col-lg-6 -->
                                </div>
                                <!-- /.row -->
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right txt_media1">
                                    Text Area
                                </label>
                            </div>
                            <div class="col-sm-10 col-md-10">
                                        <textarea rows="4" class="form-control resize_vertical"
                                                  placeholder="Basic"></textarea>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right txt_media">
                                </label>
                            </div>
                            <div class="col-sm-10 col-md-10">
                                <textarea rows="4" class="form-control resize_vertical" disabled></textarea>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-2">
                                <label class="control-label float-right">
                                </label>
                            </div>
                            <div class="col-sm-10 col-md-10">
                                        <textarea rows="4" class="form-control noresize"
                                                  placeholder="No resize"></textarea>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header txt_padding">
                    <h3 class="card-title card_header1024">
                        <i class="fa fa-fw ti-pencil"></i> Grid sizing of Form Elements
                    </h3>
                    <span class="float-right fnt_size txt_font">
                                <i class="fa fa-fw ti-angle-up clickable"></i>
                                <i class="fa fa-fw ti-close removecard"></i>
                            </span>
                </div>
                <div class="card-body">
                    <form>
                        <div class="row">

                            <div class="col-3">
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-4">
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-5">
                                <input type="text" class="form-control">
                            </div>
                        </div>

                        <br>
                        <div class="row">

                            <div class="col-3">
                                                                <textarea
                                                                        class="form-control resize_vertical"></textarea>
                            </div>
                            <div class="col-4">
                                                                <textarea
                                                                        class="form-control resize_vertical"></textarea>
                            </div>
                            <div class="col-5">
                                                                <textarea
                                                                        class="form-control resize_vertical"></textarea>
                            </div>

                        </div>
                        <br>
                        <div class="row">

                            <div class="col-3">
                                <select class="form-control">
                                    <option>Select</option>
                                </select>
                            </div>
                            <div class="col-4">
                                <select class="form-control">
                                    <option>Select</option>
                                </select>
                            </div>
                            <div class="col-5">
                                <select class="form-control">
                                    <option>Select</option>
                                </select>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header txt_padding">
                    <h3 class="card-title card_header1024">
                        <i class="fa fa-fw ti-pencil"></i> Height Sizing of Input
                        Groups
                    </h3>
                    <span class="float-right fnt_size txt_font">
                                <i class="fa fa-fw ti-angle-up clickable"></i>
                                <i class="fa fa-fw ti-close removecard "></i>
                            </span>
                </div>
                <div class="card-body">
                    <form>
                        <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-4  m-t-10">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="fa fa-fw ti-user" aria-hidden="true"></i>
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-4 m-t-10">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                     <input type="checkbox">
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-4 col-12 m-t-10">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                     <input type="radio">
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-sm-6  col-xl-4 col-12 m-t-10">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="fa fa-fw ti-user" aria-hidden="true"></i>
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6  col-xl-4 col-12 m-t-10">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                     <input type="checkbox">
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6  col-xl-4 col-12 m-t-10">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                     <input type="radio">
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-sm-6  col-xl-4 col-12 m-t-10">
                                <div class="input-group input-group-sm">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="fa fa-fw ti-user" aria-hidden="true"></i>
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6  col-xl-4 col-12 m-t-10">
                                <div class="input-group input-group-sm">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                     <input type="checkbox">
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6  col-xl-4 col-12 m-t-10">
                                <div class="input-group input-group-sm">
                                    <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                     <input type="radio">
                                                </span>
                                    </div>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header txt_padding">
                    <h3 class="card-title">
                        <i class="fa fa-fw ti-download"></i> Advanced File Input
                    </h3>
                    <span class="float-right fnt_size txt_font">
                                    <i class="fa fa-fw ti-angle-up clickable"></i>
                                    <i class="fa fa-fw ti-close removecard "></i>
                                </span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-8">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-20" type="file" class="file-loading">
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10 alert_pad">
                                Display the widget as a single block button
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-21" type="file" accept="image/*" class="file-loading">
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10">
                                Show only image files for selection & preview. Control button labels, styles,
                                and icons for the Pick Image, upload, and delete buttons.
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-22" type="file" class="file-loading" accept="text/plain"
                                   data-preview-file-type="text" data-preview-class="bg-warning">
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10">
                                Preview section control. Change preview background and display only text files
                                content within the preview window.
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8 ">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-23" type="file" class="file-loading" data-show-preview="false">
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10">
                                Advanced customization using templates. For example, Hide file preview
                                thumbnails.
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-40" type="file" class="file-loading">
                            <br>
                            <button type="button" class="btn btn-warning btn-modify text-white">Modify</button>
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10">
                                Using plugin methods to alter input at runtime. For example, click the Modify
                                button to disable the plugin and change plugin options.
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-41" type="file" class="file-loading">
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10">
                                Allow only image and video file types to be uploaded. You can configure the
                                condition for validating the file types using
                                <code>fileTypeSettings</code> .
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-42" type="file" class="file-loading">
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10">
                                Allow only specific( jpg, gif, png, txt ) file extensions.
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-sm-8">
                            <label class="control-label txt_media">
                                Select File
                            </label>
                            <input id="input-43" type="file" class="file-loading">
                            <div id="errorBlock43" class="help-block"></div>
                        </div>
                        <div class="col-sm-4">
                            <div class="alert alert-info small m-t-10">
                                Disable preview and customize your own error container and messages.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <!--main content-->

        <!--main content ends-->
        <div class="background-overlay"></div>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<!-- page level js -->
<script src="<?php echo e(asset('vendors/iCheck/js/icheck.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/bootstrap-fileinput/js/fileinput.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendors/bootstrap-fileinput/js/theme.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom_js/form_elements.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/menubarfold', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>