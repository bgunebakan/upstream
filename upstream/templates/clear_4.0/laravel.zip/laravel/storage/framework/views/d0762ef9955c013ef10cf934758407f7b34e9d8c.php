<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent("title"); ?> | Clear Admin Template </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link rel="shortcut icon" href="<?php echo e(url('img/favicon.ico')); ?>" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <!-- global css -->
    <link type="text/css" href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/layouts.css')); ?>">
    <!-- end of global css -->
    <?php echo $__env->yieldContent('header_styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/boxed.css')); ?>">
    <style>
        @media(min-width:320px) and (max-width: 425px){
            .right-side > .content-header{
                margin:0 -10px 25px -10px !important;
            }
        }
    </style>
</head>

<body class="skin-default boxed movable-header">
    <div class="preloader">
        <div class="loader_img"><img src="<?php echo e(asset('img/loader.gif')); ?>" alt="loading..." height="64" width="64"></div>
    </div>
    <!-- header logo: style can be found in header-->
    <header class="header header_movable">
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="left-side sidebar-offcanvas boxed_movable_header">
            <!-- sidebar: style can be found in sidebar-->
            <section class="sidebar">
                <div id="menu" role="navigation">
                    <?php echo $__env->make('layouts.leftmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <!-- menu -->
            </section>
            <!-- /.sidebar -->
        </aside>
        <aside class="right-side">
            <?php echo $__env->yieldContent('page-header'); ?>
            <!-- Main content -->
            <section class="content">
                <?php echo $__env->yieldContent("content"); ?>
                <!--rightside bar -->
                <?php echo $__env->make("layouts.rightside", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </section>
            <!-- /.content -->
        </aside>
        <!-- /.right-side -->
    </div>
    <!-- /.right-side -->
    <!-- ./wrapper -->
    <!-- global js -->
    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/custom_js/layout_custom.js')); ?>"></script>
    <!-- end of page level js -->
    <?php echo $__env->yieldContent('footer_scripts'); ?>
</body>

</html>
