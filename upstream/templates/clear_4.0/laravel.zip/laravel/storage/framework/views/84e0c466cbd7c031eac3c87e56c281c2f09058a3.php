  <?php $__env->startSection('title'); ?> For Editors <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link href="<?php echo e(asset('vendors/bootstrap3-wysihtml5-bower/css/bootstrap3-wysihtml5.min.css')); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo e(asset('vendors/summernote/summernote.css')); ?>">
<link href="<?php echo e(asset('vendors/trumbowyg/css/trumbowyg.min.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/form_editors.css')); ?>"> <?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>For Editors</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Forms</li>
        <li>Components</li>
        <li class="active">
            For Editors
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?>
<!-- /.box -->
<section class="content">
    <!--main content-->
    <!-- /.box -->
    <div class="card ">
        <div class="card-header">
            <div class=" bootstrap-admin-box-title ">
                <h3 class="card-title float-left">
                    Bootstrap WYSIHTML5
                </h3>
                <span class="float-right">
                        <i class="fa fa-fw ti-angle-up clickable"></i>
                        <i class="fa fa-fw ti-close removecard "></i>
                    </span>
            </div>
        </div>
        <!--main content-->
        <div class="card-body flip_editing">
            <!-- /.box -->
            <div class='card-header well well-sm'>
                <div class='box-header'>
                    <h3 class='box-title text-info float-left'>
                        Bootstrap WYSIHTML5
                        <small class="text-info">Simple editor</small>
                    </h3>
                    <!-- tools box -->
                    <div class="float-right box-tools"></div>
                    <!-- /. tools -->
                </div>
                <!-- /.box-header -->
                <div class='box-body'>
                    <form>
                        <textarea class="textarea editor-cls" placeholder="Place some text here"></textarea>
                    </form>
                </div>
            </div>
            <!-- /.col-->
        </div>
    </div>
    <div class="card ">
        <div class="card-header">
            <div class=" bootstrap-admin-box-title ">
                <h3 class="card-title float-left">
                    Summer Note</h3>
                <span class="float-right">
                        <i class="fa fa-fw ti-angle-up clickable"></i>
                        <i class="fa fa-fw ti-close removecard "></i>
                    </span>
            </div>
        </div>
        <div class="card-body">
            <div class="bootstrap-admin-card-content summer_noted">
                <div id="summernote"></div>
            </div>
        </div>
    </div>
    <div class="card ">
        <div class="card-header">
            <div class=" bootstrap-admin-box-title ">
                <h3 class="card-title float-left">
                    Flip Editor</h3>
                <span class="float-right">
                        <i class="fa fa-fw ti-angle-up clickable"></i>
                        <i class="fa fa-fw ti-close removecard "></i>
                    </span>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="bootstrap-admin-card-content flip_editing">
                    <textarea class="" id="split_editor"></textarea>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script src="<?php echo e(asset('vendors/bootstrap3-wysihtml5-bower/js/bootstrap3-wysihtml5.all.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendors/trumbowyg/js/trumbowyg.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('vendors/bootstrap3-wysihtml5-bower/js/bootstrap3-wysihtml5.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendors/summernote/summernote.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom_js/form_editors.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/menubarfold', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>