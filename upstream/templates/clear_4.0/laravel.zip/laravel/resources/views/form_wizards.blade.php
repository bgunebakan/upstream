@extends('layouts/default') {{-- Page title --}} @section('title') Form Wizards @stop {{-- local styles --}} @section('header_styles')
<link href="{{asset('vendors/select2/css/select2.min.css')}}" type="text/css" rel="stylesheet">
<link href="{{asset('vendors/select2/css/select2-bootstrap.css')}}" rel="stylesheet">
<link href="{{asset('vendors/bootstrapvalidator/css/bootstrapValidator.min.css')}}" rel="stylesheet">
<link href="{{asset('vendors/iCheck/css/all.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('css/custom_css/wizard.css')}}" rel="stylesheet">
@stop {{-- Page Header--}} @section('page-header')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Form Wizards</h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{url('index')}}">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Forms</li>
        <li>Components</li>
        <li class="active">
            Form Wizards
        </li>
    </ol>
</section>
@stop {{-- Page content --}} @section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <h3 class="card-title">
                        Bootstrap Wizard
                    </h3>
                    <span class="float-right">
                        <i class="fa fa-fw ti-angle-up clickable"></i>
                        <i class="fa fa-fw ti-close removecard "></i>
                    </span>
                </div>
                <div class="card-body">
                    <div class="stepwizard">
                        <div class="stepwizard-row setup-card">
                            <div class="stepwizard-step">
                                <a href="#step-1" class="btn btn-primary btn-block">1</a>
                                <p>Step 1</p>
                            </div>
                            <div class="stepwizard-step">
                                <a href="#step-2" class="btn btn-default btn-block">2</a>
                                <p>Step 2</p>
                            </div>
                            <div class="stepwizard-step">
                                <a href="#step-3" class="btn btn-default btn-block">3</a>
                                <p>Step 3</p>
                            </div>
                        </div>
                    </div>
                    <form role="form">
                        <div class="row setup-content" id="step-1">
                            <div class="col-12">
                                <div class="col-md-12">
                                    <h3> Step 1</h3>
                                    <div class="form-group">
                                        <label for="step_fname" class="control-label">First Name</label>
                                        <input id="step_fname" maxlength="100" type="text" class="form-control"
                                               placeholder="Enter First Name"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="step_lname" class="control-label">Last Name</label>
                                        <input id="step_lname" maxlength="100" type="text" class="form-control"
                                               placeholder="Enter Last Name"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="step_email" class="control-label">Email</label>
                                        <input id="step_email" maxlength="100" type="email" class="form-control"
                                               placeholder="Enter Email Address"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="step_cemail" class="control-label">Confirm Email</label>
                                        <input id="step_cemail" maxlength="100" type="email"
                                               class="form-control"
                                               placeholder="Re-enter Your Email"/>
                                    </div>
                                    <button class="btn btn-primary nextBtn float-right" type="button">
                                        Next
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row setup-content" id="step-2">
                            <div class="col-12">
                                <div class="col-md-12">
                                    <h3> Step 2</h3>
                                    <div class="form-group">
                                        <label for="step_cname" class="control-label">Company Name</label>
                                        <input id="step_cname" maxlength="200" type="text" class="form-control"
                                               placeholder="Enter Company Name"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="step_cadd" class="control-label">Company Address</label>
                                        <input id="step_cadd" maxlength="200" type="text" class="form-control"
                                               placeholder="Enter Company Address"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="step_pwd" class="control-label">Password</label>
                                        <input id="step_pwd" maxlength="12" type="password" class="form-control"
                                               placeholder="Enter password"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="step_cpwd" class="control-label">Confirm Password</label>
                                        <input id="step_cpwd" maxlength="12" type="password"
                                               class="form-control"
                                               placeholder="Confirm password"/>
                                    </div>
                                    <button class="btn btn-primary prevBtn pull-left" type="button">
                                        Previous
                                    </button>
                                    <button class="btn btn-primary nextBtn float-right" type="button">
                                        Next
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row setup-content" id="step-3">
                            <div class="col-12">
                                <div class="col-md-12">
                                    <h3> Step 3</h3>
                                    <div class="form-group">
                                        <label for="acceptTerms1">
                                            <input id="acceptTerms1" name="acceptTerms" type="checkbox"
                                                   class="custom-checkbox"> I agree with the <a
                                                    href="javascript:void(0)">terms &amp; Conditions</a>.
                                        </label>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-primary prevBtn pull-left" type="button">
                                            Previous
                                        </button>
                                        <button class="btn btn-success float-right" type="submit">
                                            Finish!
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@stop {{-- local scripts --}} @section('footer_scripts')
<script src="{{asset('vendors/iCheck/js/icheck.js')}}"></script>
<script src="{{asset('vendors/moment/js/moment.min.js')}}"></script>
<script src="{{asset('vendors/select2/js/select2.js')}}" type="text/javascript"></script>
<script src="{{asset('vendors/bootstrapwizard/js/jquery.bootstrap.wizard.js')}}" type="text/javascript"></script>
<script src="{{asset('vendors/bootstrapvalidator/js/bootstrapValidator.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/custom_js/form_wizards.js')}}" type="text/javascript"></script> @stop
