@extends('layouts/default') {{-- Page title --}} @section('title') Advanced Calendar @stop {{-- local styles --}} @section('header_styles')
<link href="{{asset('vendors/bootstrap-calendar/css/calendar.min.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{asset('vendors/jquerydaterangepicker/css/daterangepicker.min.css')}}">
<link href="{{asset('vendors/iCheck/css/all.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('css/calendar_custom2.css')}}" rel="stylesheet" type="text/css" /> @stop {{-- Page Header--}} @section('page-header')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Advanced Calendar</h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{url('index')}}">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Calendar</li>
        <li class="active">
            Advanced Calendar
        </li>
    </ol>
</section>
@stop {{-- Page content --}} @section('content')
    <div class="page-header">
        <div class="float-right form-inline">
            <div class="btn-group mr-1">
                <button class="btn btn-primary" data-calendar-nav="prev">
                    <i class="fa fa-fw ti-angle-double-left" aria-hidden="true"></i> Prev
                </button>
                <button class="btn btn-default" data-calendar-nav="today">Today</button>
                <button class="btn btn-primary" data-calendar-nav="next">Next <i
                            class="fa fa-fw ti-angle-double-right" aria-hidden="true"></i>
                </button>
            </div>
            <div class="btn-group">
                <button class="btn btn-warning" data-calendar-view="year">Year</button>
                <button class="btn btn-warning active" data-calendar-view="month">Month</button>
                <button class="btn btn-warning" data-calendar-view="week">Week</button>
                <button class="btn btn-warning" data-calendar-view="day">Day</button>
            </div>
        </div>
        <h3></h3>
    </div>
    <div class="row">
        <div class="col-md-9">
            <div id="calendar" class="m-b-25"></div>
        </div>
        <div class="col-md-3 calendar-settings">
            <div class="row">
                <div class="col-md-12">
                    <h4>Calendar Settings</h4>
                    <div class="row">
                        <div class="col-12">
                            <label for="first_day">First day of week </label>
                        </div>
                        <div class="col-12">
                            <select id="first_day" class="form-control">
                                <option value="" selected="selected">language-dependant</option>
                                <option value="2">Sunday</option>
                                <option value="1">Monday</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <label for="language">Select Language</label>
                        </div>
                        <div class="col-12">
                            <select id="language" class="form-control">
                                <option value="">default: English-US</option>
                                <option value="bg-BG">Bulgarian</option>
                                <option value="nl-NL">Dutch</option>
                                <option value="fr-FR">French</option>
                                <option value="de-DE">German</option>
                                <option value="el-GR">Greek</option>
                                <option value="hu-HU">Hungarian</option>
                                <option value="id-ID">Bahasa Indonesia</option>
                                <option value="it-IT">Italian</option>
                                <option value="pl-PL">Polish</option>
                                <option value="pt-BR">Portuguese (Brazil)</option>
                                <option value="ro-RO">Romania</option>
                                <option value="es-CO">Spanish (Colombia)</option>
                                <option value="es-MX">Spanish (Mexico)</option>
                                <option value="es-ES">Spanish (Spain)</option>
                                <option value="ru-RU">Russian</option>
                                <option value="sk-SR">Slovak</option>
                                <option value="sv-SE">Swedish</option>
                                <option value="zh-CN">简体中文</option>
                                <option value="zh-TW">繁體中文</option>
                                <option value="ko-KR">한국어</option>
                                <option value="th-TH">Thai (Thailand)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 m-t-10">
                    <label class="checkbox">
                        <input type="checkbox" value="#events-modal" id="events-in-modal"> Open events
                        in modal window
                    </label>
                </div>
                <div class="col-md-12 m-t-10">
                    <label class="checkbox">
                        <input type="checkbox" id="format-12-hours"> 12 Hour format
                    </label>
                </div>
                <div class="col-md-12 m-t-10">
                    <label class="checkbox">
                        <input type="checkbox" id="show_wb" checked> Show week box
                    </label>
                </div>
                <div class="col-md-12 m-t-10">
                    <label class="checkbox">
                        <input type="checkbox" id="show_wbn" checked> Show week box number
                    </label>
                </div>


                <div class="col-md-12">
                    <hr>
                </div>
                <div class="col-md-12">
                    <div>
                        <h4>Events List</h4>
                    </div>
                    <div id="eventlist">
                        <ul class="nav nav-list"></ul>
                    </div>
                    <div class="m-t-10">
                        <a href="#" class="btn btn-success btn-block" data-toggle="modal"
                           data-target="#myModal">Create
                            event</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel">
                        <i class="fa ti-plus icon-align"></i> Create Event
                    </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>

                </div>
                <div class="modal-body">
                    <div role="form" id="eventform">
                        <div class="modal-body">
                            <div class="col-12">
                                <label for="new-event">Event Name</label>
                            </div>
                            <div class="col-12">
                                <input type="text" id="new-event" class="form-control" placeholder="Event">
                            </div>
                            <div class="col-12">
                                <label for="eventclass">Event Class</label>
                            </div>
                            <div class="col-12">
                                <select name="eventclass" id="eventclass" class="form-control">
                                    <option value="event-important" selected>Important</option>
                                    <option value="event-success">Success</option>
                                    <option value="event-primary">primary</option>
                                    <option value="event-default">Default</option>
                                    <option value="event-info">Info</option>
                                    <option value="event-warning">Warning</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label for="event_url">Event URL</label>
                            </div>
                            <div class="input-group col-12">
                                <span class="input-group-addon" id="basic-addon3">https://</span>
                                <input type="text" class="form-control" id="event_url" aria-describedby="basic-addon3" placeholder="Enter The URL related to event">
                            </div>
                            <div class="col-12">
                                <label for="date-range0">Date Range</label>
                            </div>
                            <div class="col-12">
                                <input type="text" class="form-control float-right" id="date-range0"
                                       placeholder="Select Date Range For Event"/>
                            </div>
                            <!-- /input-group -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-danger float-right" id="close_calendar_event"
                            data-dismiss="modal">
                        Close
                        <i class="fa ti-close icon-align"></i>
                    </button>
                    <button type="button" class="btn btn-success float-left" id="add-new-event">
                        <i class="fa ti-plus icon-align"></i> Add
                    </button>
                    <button type="reset" class="d-none">Reset</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="events-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h3>Event</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body" style="height: 400px">
                </div>
                <div class="modal-footer">
                    <a href="#" data-dismiss="modal" class="btn btn-danger">Close</a>
                </div>
            </div>
        </div>
    </div>
@stop {{-- local scripts --}} @section('footer_scripts')
<script src="{{asset('vendors/moment/js/moment.min.js')}}" type="text/javascript"></script>
<script src="{{asset('vendors/jquerydaterangepicker/js/jquery.daterangepicker.min.js')}}" type="text/javascript"></script>
<script src="{{asset('vendors/underscore/js/underscore-min.js')}}" type="text/javascript"></script>
<script src="{{asset('vendors/bootstrap-calendar/js/calendar.min.js')}}" type="text/javascript"></script>
<script src="{{asset('vendors/iCheck/js/icheck.js')}}" type="text/javascript"></script>
<script src="{{asset('js/custom_js/calendar_custom2.js')}}" type="text/javascript"></script>
@stop
