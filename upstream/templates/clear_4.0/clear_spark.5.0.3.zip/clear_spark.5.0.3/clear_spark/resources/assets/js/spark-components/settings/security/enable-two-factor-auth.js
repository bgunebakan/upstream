var base = require('settings/security/enable-two-factor-auth');

Vue.component('spark-enable-two-factor-auth', {
    mixins: [base]
});
