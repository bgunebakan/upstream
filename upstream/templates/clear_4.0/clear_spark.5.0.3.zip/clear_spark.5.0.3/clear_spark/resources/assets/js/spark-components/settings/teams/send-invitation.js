var base = require('settings/teams/send-invitation');

Vue.component('spark-send-invitation', {
    mixins: [base]
});
