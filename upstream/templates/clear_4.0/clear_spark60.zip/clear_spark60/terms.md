Your terms of service.

Simply edit this file to define the terms of service for your application.
