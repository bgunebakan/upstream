var base = require('settings/payment-method-stripe');

Vue.component('spark-payment-method-stripe', {
    mixins: [base]
});
