<h6 class="dropdown-header">{{__('Developer')}}</h6>

<!-- Kiosk -->
<a class="dropdown-item" href="/spark/kiosk">
    <i class="fa fa-fw text-left fa-btn fa-fort-awesome"></i> {{__('Kiosk')}}
</a>

<div class="dropdown-divider"></div>
