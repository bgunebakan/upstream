<?php

namespace Laravel\Spark;

class TeamPlan extends Plan
{
}
