<template>
    <div class="panel nvd3-panel">
        <div class="panel-heading">
            <h3 class="panel-title">Project Status</h3>
        </div>
        <div class="panel-body">
            <div class="nvd3-chart line-chart text-center" data-x-grid="false">
                <svg></svg>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        name: "project_status",
        mounted: function(){

        },
    destroyed:function(){
        }
    }
</script>