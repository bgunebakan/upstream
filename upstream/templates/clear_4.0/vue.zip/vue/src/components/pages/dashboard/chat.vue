<?xml version="1.0" encoding="UTF-8"?>
<project version="4">
  <component name="ChangeListManager">
    <list default="true" id="3fd7e8e4-745a-42a7-9259-f9828e669817" name="Default" comment="">
      <change type="MODIFICATION" beforePath="$PROJECT_DIR$/src/assets/css/custom_css/wizard.css" afterPath="$PROJECT_DIR$/src/assets/css/custom_css/wizard.css" />
      <change type="MODIFICATION" beforePath="$PROJECT_DIR$/src/components/pages/index2.vue" afterPath="$PROJECT_DIR$/src/components/pages/index2.vue" />
    </list>
    <option name="EXCLUDED_CONVERTED_TO_IGNORED" value="true" />
    <option name="TRACKING_ENABLED" value="true" />
    <option name="SHOW_DIALOG" value="false" />
    <option name="HIGHLIGHT_CONFLICTS" value="true" />
    <option name="HIGHLIGHT_NON_ACTIVE_CHANGELIST" value="false" />
    <option name="LAST_RESOLUTION" value="IGNORE" />
  </component>
  <component name="FileEditorManager">
    <leaf SIDE_TABS_SIZE_LIMIT_KEY="300">
      <file leaf-file-name="_right_side_bar.scss" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/assets/sass/dark/_right_side_bar.scss">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="510">
              <caret line="34" column="15" lean-forward="false" selection-start-line="34" selection-start-column="15" selection-end-line="34" selection-end-column="15" />
              <folding />
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="index.vue" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/components/pages/index.vue">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="-22">
              <caret line="372" column="75" lean-forward="false" selection-start-line="372" selection-start-column="75" selection-end-line="372" selection-end-column="75" />
              <folding />
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="_variables.scss" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/assets/sass/bootstrap/_variables.scss">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="82">
              <caret line="43" column="17" lean-forward="true" selection-start-line="43" selection-start-column="17" selection-end-line="43" selection-end-column="17" />
              <folding />
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="bootstrap.scss" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/assets/sass/bootstrap/bootstrap.scss">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="255">
              <caret line="17" column="7" lean-forward="true" selection-start-line="17" selection-startc10lumn="7" selection-end-line="17" selection-end-column="7" />
              <folding />
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="form-validations.vue" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/components/pages/form-validations.vue">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="120">
              <caret line="8" column="72" lean-forward="false" selection-start-line="8" selection-start-column="72" selection-end-line="8" selection-end-column="72" />
              <folding>
                <element signature="e#33092#33166#0" expanded="true" />
                <marker date="1509618976122" expanded="true" signature="47915:47931" ph="..." />
              </folding>
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="form-layouts.vue" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/components/pages/form-layouts.vue">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="1695">
              <caret line="711" column="83" lean-forward="false" selection-start-line="711" selection-start-column="83" selection-end-line="711" selection-end-column="83" />
              <folding>
                <element signature="n#div#0;n#b-tab#0;n#b-tabs#0;n#b-card#0;n#div#0;n#div#0;n#div#0;n#template#0;n#!!top" expanded="false" />
                <element signature="n#div#1;n#b-tab#1;n#b-tabs#0;n#b-card#0;n#div#0;n#div#0;n#div#0;n#template#0;n#!!top" expanded="false" />
                <element signature="n#div#0;n#b-tab#3;n#b-tabs#0;n#b-card#0;n#div#0;n#div#0;n#div#0;n#template#0;n#!!top" expanded="false" />
              </folding>
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="wizard.css" pinned="false" current-in-tab="true">
        <entry file="file://$PROJECT_DIR$/src/assets/css/custom_css/wizard.css">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="217">
              <caret line="197" column="32" lean-forward="false" selection-start-line="197" selection-start-column="32" selection-end-line="197" selection-end-column="32" />
              <folding />
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="dropdowns.vue" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/components/pages/dropdowns.vue">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="464">
              <caret line="516" column="94" lean-forward="false" selection-start-line="516" selection-start-column="94" selection-end-line="516" selection-end-column="94" />
              <folding>
                <element signature="e#46976#47070#0" expanded="true" />
              </folding>
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="_left_menu.scss" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/assets/sass/dark/_left_menu.scss">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="1095">
              <caret line="73" column="0" lean-forward="false" selection-start-line="73" selection-start-column="0" selection-end-line="73" selection-end-column="0" />
              <folding />
            </state>
          </provider>
        </entry>
      </file>
      <file leaf-file-name="index2.vue" pinned="false" current-in-tab="false">
        <entry file="file://$PROJECT_DIR$/src/components/pages/index2.vue">
          <provider selected="true" editor-type-id="text-editor">
            <state relative-caret-position="112">
              <caret line="552" column="24" lean-forward="false" selection-start-line="552" selection-start-column="24" selection-end-line="552" selection-end-column="24" />
              <folding />
            </state>
          </provider>
        </entry>
      